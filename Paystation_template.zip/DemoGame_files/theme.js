$(document).ready(function(){
    setFooterTop();
})
$(window).resize(function(){
    setFooterTop();
});

function setFooterTop(){
    $('#footer').css({position: 'fixed', width: '100%'});
    $('#content').css({'margin-bottom': '60px'});

    var docH = $(window).height() - $('#footer').outerHeight(true);
    var bodyH = $('#header').outerHeight(true) + $('#content').outerHeight(true) - $('#footer').outerHeight(true);
    $('#footer').css('top', (Math.min(docH, bodyH)) + 'px');

}


var num = 0;
function initPaymentOpen(){
    if($('#update_size_mode').length && $('#update_size_mode').val() == 1){

        $('#resize').show().appendTo('body').show();
        $('#doc').hide();
        $('#pay').attr({'target':'framepay'});
        $('#pay').submit();

        $('[name=framepay]').show().load(function(){
            $('#framediv').resizable();
        });

    }else{
        if($('#pay').length == 1 && $('[name=paywidth]').length == 1 && $('[name=payheight]').length == 1){
            var updateStatus = false;
            var bWidth = $('#payment-content').width();
            if($('[name=paywidth]').val() <= bWidth){
                $('#pay').attr('target', 'framepayment');
                $('#frame').show();
                $('#pay').hide();
                $('#payment-content h3').remove();
                $('#payment-content').css('padding', '0');
            }else{
                var win = window.open('', 'pay'+num);
                $('#pay').attr('target', 'pay'+num);
                setTimeout(function () {
                    if (win.closed){
                            $('#xsolla_form').submit();
                        }
                        else{
                            setTimeout(arguments.callee,500);
                        }
                }, 500);
                updateStatus = true;
                num++;
            }
            $('#pay').submit();
        }

    }
}


function monitorStatus(){

}
