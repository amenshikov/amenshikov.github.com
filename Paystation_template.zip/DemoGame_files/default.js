$(document).ready(function(){
    if($.browser.msie){
        $('input:text').each(function(ind, el){
            if($(el).attr('placeholder')){
                if($(el).val() == '') $(el).val($(el).attr('placeholder'));
                $(el).focus(function(){
                    if($(el).val() == $(el).attr('placeholder')) $(el).val('');
                }).blur(function(){
                    if($(el).val() == '') $(el).val($(el).attr('placeholder'));
                })
            }
        })
    };
    loadRemoveLoading();
})

var preloaderTimer;
function initLoad(){
    var $p = $('body');
    $('#load').height($p.height()).width($p.width()).css({
        'z-index': '110'
    }).show();

    $('#load-layer').css({
        'height': $p.height(),
        'width': $p.width(),
        'opacity':'0.7'}
    ).show();

    preloaderTimer = setInterval('loadChangeBgPosition()', 90);
}

function loadChangeBgPosition(){
    var pos = $('#load-bg').css('backgroundPosition');
    var top = parseInt(pos);
    top -= 64;
    if(top <= -640) top = 0;
    $('#load-bg').css({'backgroundPosition': top+'px 0', 'position':'relative'});
}

function loadRemoveLoading(){
    clearTimeout(preloaderTimer);
    $('#load, #load-layer').hide();
}




