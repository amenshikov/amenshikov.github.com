var imageArray = [];

$(document).ready(function(){
   init();
})

$(window).resize(function(){
    heightInit(true);
})

var preloaderTimer;

function init(){

    leftMinHeightInit();
    getImageArray();
    
    groupInit();
    searchInit();
    heightInit();
    countryInit();
    scrollAlert();

    clickPS();

    $('#more > div').html(TRANSLATE['show_more'])
}

function groupInit(){
    $('#group-options li.filter').live('click', function(event){
       filterGroup($(event.target).attr('data-value'));
       $(event.target).parent().parent().children('li').removeClass('active');
       $(event.target).parent().addClass('active');
       document.cookie = 'ps['+data['project_id']+'][id_rubrik]='+$(event.target).attr('data-value');
    });

    $('#group-options li.active a').trigger('click');
}




function filterGroup(groupID){
    $('#plugin').hide();
    $('#payment-list, #more').show();
    
    $('[data-id *= group]').hide().removeClass('searchVis');
    $('[data-id *= '+groupID+']').show().addClass('searchVis');

    $('#currentGroup').val(groupID);
    $('#search > input:text').val('');
    heightInit();
    $('#more > div').html(TRANSLATE['show_more']).removeClass('less');

    if($('#payment-list .payment:visible').length == 0 && $('#plugin:visible').length == 0){
        $('#empty-list').show();
    }else{
        $('#empty-list').hide();
    }
}

var searchTimer;
function searchInit(){
    var pList = [];

    $('a.payment > input:hidden').each(function(ind, el){
        pList.push($(el).val());
    });

    $( "#search > input:text" ).autocomplete({
        minLength: 0,
        source: pList,
        select: function(event, ui){
            var target;
            $('a.payment > input:hidden').each(function(ind, el){
                if($(el).val() == ui.item.value){
                    target = $(el).parent();
                }
            });
            document.location.href = target.attr('href');
        }
    });
}

function search(){
    var search = $('#search > input:text').val();
    $('a.searchVis').each(function(ind, el){
        var html = $(el).children('input:hidden').val();

        if(html.toLowerCase().indexOf(search.toLowerCase()) == -1 && search != '') {
            $(el).hide();
        }else{
            $(el).show();
        }
    });
    heightInit();
}

function heightInit(isResize){
    isResize = isResize || false;
    var h;
    if(isResize) h = $('#payment-list').height();
    else $('#more').show();


    var hMore = $('#more').outerHeight(true);
    
    var hLeft = $('#left > div').outerHeight(true);
    $('#payment-list').height('auto');
    var hRight = $('#payment-list').height();
    if(hLeft < hRight && $('#plugin:visible').length == 0 && $('#temp:visible').length == 0){
        $('#more').show();
        hMore = $('#more').outerHeight(true);
        if(!isResize){
            $('#payment-list').height(hLeft - hMore).css('overflow-y','hidden');
        }
    }else{
        $('#left > div').height(hLeft - parseInt($('#left > div').css('margin-top')));
        $('#more').hide();
    }
    if(isResize){
        hMore = $('#more').outerHeight(true); 
        if($('#payment-list').css('overflow-y') == 'auto'){
            $('#payment-list').height('auto');
        }else{
            $('#payment-list').height(Math.max(h, hLeft - hMore));
        }
    }

    imageInit();
}

function showMore(){
   //$('#more').hide();
   if($('#payment-list').css('overflow-y') == 'auto'){
       $('html, body').animate({scrollTop: 0}, 800, function(){
           heightInit();
           if(typeof setFooterTop == 'function'){
               setFooterTop();
           }
        });
       $('#more > div').html(TRANSLATE['show_more']).removeClass('less');
   }else{
       $('#payment-list').height('auto').css('overflow-y','auto');
       $('html, body').animate({scrollTop: $('#left > div').height() + 80}, 800, function(){
           if(typeof setFooterTop == 'function'){
               setFooterTop();
           }
       });
       $('#more > div').html(TRANSLATE['show_less']).addClass('less');

       imageInit();
       //$('#more').
   }
   if(typeof setFooterTop == 'function'){
       setFooterTop();
   }
   /*if($('#payment-list').hasClass('full')){
       //$('html, body').animate({scrollTop: 0}, 800, function(){heightInit()});
       //, function(){heightInit()
       $('#payment-list').removeClass('full').css('overflow-y','hidden').animate({scrollTop: 0}, 800);
       $('#more > div').html(TRANSLATE['show_more']).removeClass('less');
       //heightInit();
   }else{
       $('#payment-list').css('overflow-y','auto').addClass('full').animate({scrollTop: '685'}, 800);
       //$('html, body').animate({scrollTop: $('#left > div').height() + 80}, 800);
       $('#more > div').html(TRANSLATE['show_less']).addClass('less');
       //$('#more').
   }*/
   
}

function openFrame(ob){
    $(ob).parent().parent().children('li').removeClass('active');
    $(ob).parent().addClass('active');
    $('#more > div').html(TRANSLATE['show_more']).removeClass('less');
    

    loadRemoveLoading();
    //$('<div id="load"></div>').appendTo('#doc');
    initLoad();
    $('#plugin').attr('src', $(ob).attr('href')).load(function(){
        if($(ob).parent().hasClass('active')){
            $('#plugin').show();
            loadRemoveLoading();
            $('#payment-list, #more').hide();
        }
    });
}

function countryInit(){
    $('.autocomlete').autocomplete({
        source: 'index.php/paystation/?section=country&ajax=1'+genParamUrl(),
        minLength: 0,
        delay:700,
        select: function(event, ui){
            var url='index.php?&secondload&country='+ui.item.id+genParamUrl();

            eval("yaCounter"+data['metrika']+".reachGoal('COUNTRY_CHANGE')");
            //alert(url);
            document.location.href = url;
        },
        search: function(event, ui) {
            /*var str = '<div class="preloader"></div>';
            $(str).appendTo('body');
            var h = parseInt(($('#doc').height() - 64) / 2);
            var w = parseInt(($('#doc').width() - 64) / 2);
            $('.preloader').css({'top': w+'px', 'left': h+'px'});
            $('#right').css('opacity', 0.7);
            
            preloaderTimer = setInterval('changeBgPosition()', 500)
            $('.preloader').css({'left':w+'px', 'top':h+'px'});
            setTimeout('removeLoading()', 3000);*/

        },
        open: function(event, ui){
            removeLoading();
        }
    })

    $('#country > input:text').bind({
    focusin: function(){
       if($('#country > input:text').attr('placeholder') ==  $('#country > input:text').val()){
           $('#country > input:text').val('');
       }
    },
    focusout: function(){
        if($('#country > input:text').val() == ''){
           $('#country > input:text').val($('#country > input:text').attr('placeholder'));
       }
    }
    });

    $('.autocomlete').click(function(){
        if($('.autocomlete').val() == ''){
            $('.autocomlete').autocomplete( "search" , '' );
        }
    });
}

function changeBgPosition(){
    var pos = $('.preloader').css('backgroundPosition');
    var top = parseInt(pos);
    top -= 64;
    if(top <= -640) top = 0;
    $('.preloader').css('backgroundPosition', top+'px top');
}

function removeLoading(){
    $('#right').css('opacity', 1);
    clearTimeout(preloaderTimer);
    $('.preloader').remove();
}

function genParamUrl(){
    data['project_id'] = data['project_id'] || '';
    data['theme_id'] = data['theme_id'] || '';
    data['v1'] = data['v1'] || '';
    data['v2'] = data['v2'] || '';
    data['v3'] = data['v3'] || '';
    data['out'] = data['out'] || '';
    data['pricepoints'] = data['pricepoints'] || '';
    data['email'] = data['email'] || '';
    data['currency'] = data['currency'] || '';
    data['signature'] = data['signature'] || '';

    var url = '';
    if(data['project_id']) url += '&projectid='+data['project_id'];
    if(data['theme_id']) url += '&id_theme='+data['theme_id'];
    if(data['v1']) url += '&v1='+data['v1'];
    if(data['v2']) url += '&v2='+data['v2'];
    if(data['v3']) url += '&v3='+data['v3'];
    if(data['out']) url += '&out='+data['out'];
    if(data['email']) url += '&email='+data['email'];
    if(data['pricepoints']) url += '&pricepoints='+data['pricepoints'];
    if(data['currency']) url += '&currency='+data['currency'];
    if(data['signature']) url += '&signature='+data['signature'];

    return url;
}

function imageInit(){
    var pos;
    var tempArray = [];
    for(i in imageArray){
        var $el = $('#'+imageArray[i]);
        var pos = $el.position();  
        if(pos.top < $('#payment-list').height()){
            var $img = $el.find('img');
            $img.attr('src', $img.attr('data'));
        }else{
            tempArray.push(imageArray[i]);
        }
    }
    imageArray = tempArray;
}

function getImageArray(){
    $('a.payment').each(function(ind, el){
        imageArray.push($(el).attr('id'));
    });
}

/*Увеличение высоты левой области, для того чтобы не обрезались платежки */
function leftMinHeightInit(){
    var h = $('#payment-list').children('a').eq(0).outerHeight(true);
    var minH = Math.ceil($('#left').height() / h) * h + $('#more').outerHeight(true) - parseInt($('#left > div').css('margin-top'));
    $('#left > div').css('min-height', minH+'px');
}

/*Монитоинг открытия PayStation со скролом и алерта на почту в случаи появления скрола*/
function scrollAlert(){
    if($(document).height() > $(window).height() && data['theme_id'] == 34){
        $.ajax({
            url: 'index.php',
            type: 'GET',
            dataType: 'text',
            data: {
                projectid: data['project_id'],
                id_theme: data['theme_id'],
                ajax: 1,
                section: 'alertscroll'
            }
        })
    }
}

/*Скрытие платежек и появление прелоадера при выборе способа оплаты*/
function clickPS(){
    $('#payment-list > a').click(function(){
       
        
        //$('<div id="load"></div>').appendTo('#doc');
        initLoad();
    });
}